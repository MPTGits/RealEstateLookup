class HTTPMethod:
    GET = 'GET'
    POST = 'POST'
    PUT = 'PUT'